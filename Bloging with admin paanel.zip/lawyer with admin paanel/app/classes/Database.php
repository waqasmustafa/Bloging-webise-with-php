<?php


namespace App\classes;


class Database
{
    public function db()
    {
        $link = mysqli_connect('localhost','root','','blog_oop2');
        return $link;
    }
}