<?php
require_once 'vendor/autoload.php';
use App\classes\Post;
use App\classes\Site;
$ob = Site::display();
$siteData = mysqli_fetch_assoc($ob);
#$post = Post::showActivelPost();
$populer = Post::showPopulerlPost();
$page = explode('/',$_SERVER['PHP_SELF']);
$page = end($page);
$title = '';
if($page == 'index.php'){
    $title = 'Home';
}
elseif ($page == 'contact.php'){
    $title = 'Contact';
}
?>

<?php 
use App\classes\Helper;
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>Buero-Strafrech</title>
    <!-- FONTS -->
    <link href="https://fonts.googleapis.com/css?family=Gudea:400,400i,700%7CPT+Serif:400,400i,700,700i%7CSlabo+27px&amp;subset=cyrillic,cyrillic-ext,latin-ext" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Cabin:600" rel="stylesheet">
    <!-- STYLES -->
    <!-- libs -->
    <link rel="stylesheet" href="css/fontello.css">
    <link rel="stylesheet" href="css/foundation/foundation.css">
    <link rel="stylesheet" href="css/swiper.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <!-- custom -->
    <link rel="stylesheet" href="css/main.css">
    <!-- LayerSlider stylesheet -->
    <link rel="stylesheet" href="layerslider/css/layerslider.css" type="text/css">
    <!-- google map location -->
   
    <link rel="apple-touch-icon" sizes="180x180" href="images/favicon.jpg">
    <link rel="icon" type="image/png" href="images/favicon.jpg" sizes="32x32">
    <link rel="icon" type="image/png" href="images/favicon.jpg" sizes="16x16">

    <link rel="shortcut icon" href="images/favicon.jpg">
    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> -->
    <meta name="msapplication-TileColor" content="#ffc40d">
    <meta name="msapplication-TileImage" content="images/favicon/mstile-144x144.png">
    <meta name="msapplication-config" content="images/favicon/browserconfig.xml">
    <meta name="theme-color" content="#ffffff">
</head>

<body>

    <!-- HEADER -->
    <header class="main-header ">
       <div class="row-fluid row-fluid--socials">
			<div class="row align-right">
				<div class="columns shrink">
					<div class="socials socials--slide-hover">
						<a href="#">
							<i class="icon-twitter fa fa-hover"></i>
							<i class="icon-twitter"></i>
						</a>
						<a href="#">
							<i class="icon-facebook icon-hover"></i>
							<i class="icon-facebook"></i>
						</a>
						<a href="#">
							<i class="icon-linkedin icon-hover"></i>
							<i class="icon-linkedin"></i>
						</a>
						<a href="#">
							<i class="icon-pinterest-4 icon-hover"></i>
							<i class="icon-pinterest-4"></i>
						</a>
						<a href="#">
							<i class="icon-rss-1 icon-hover"></i>
							<i class="icon-rss-1"></i>
						</a>
						<a href="#">
							<i class="icon-gplus-1 icon-hover"></i>
							<i class="icon-gplus-1"></i>
						</a>
					</div>

				</div>
			</div>
		</div>
        <div class="row-fluid" id="js-menu-sticky-anchor">
            <div class="row align-justify align-middle row-logo">
                <div class="columns small-12 medium-6">
                    <div class="logo">
                        <a href="/">

							<img src="images/logo.png" alt="Logo" style="width: 300px;">

						</a>
                    </div>
                </div>
                <div class="columns small-12 shrink">
                    <div class="contact-phone">
                        <i class="fa fa-phone"></i> Free Consultation: <span>+49 621 120 91-0</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="sticky-container">
            <div class="row-fluid row-fluid--menu js-sticky">
                <div class="row align-middle main-navigation">

                    <div class="columns small-order-2 large-order-1 menu-col">
                        <nav>
                            <ul class="menu main-menu">
                                <li class="menu-item current-menu-parent menu-item-has-children">
                                    <a href="/">Startseite</a>
                                   
                                </li>
                                <li class="menu-item  ">
                                    <a href="#people">Unsere Verteidiger</a>
                                    <ul class="menu sub-menu">
                                        <li class="menu-item ">
                                            <a href="Thomas Dominkovic.html">Thomas Dominkovic</a>
                                        </li>
                                        <li class="menu-item ">
                                            <a href="Kayahan Aydin.html">Kayahan Aydin</a>
                                        </li>
                                 
                                    </ul>
                                </li>
                                <li class="menu-item  ">
                                    <a href="">Bereiche des Strafrechts</a>
                                    <ul class="menu sub-menu">
                                        <li class="menu-item ">
                                            <a href="Betäubungsmittelstrafrecht.html">Betäubungsmittelstrafrecht</a>
                                        </li>
                                        <li class="menu-item ">
                                            <a href="Internetstrafrecht.html">Internetstrafrecht</a>
                                        </li>
                                        <li class="menu-item ">
                                            <a href="Jugendstrafrecht.html">Jugendstrafrecht</a>
                                        </li>
                                        <li class="menu-item ">
                                            <a href="Verkehrsstrafrecht.html">Verkehrsstrafrecht
                                            </a>
                                        </li>
                                        <li class="menu-item ">
                                            <a href="Sexualstrafrecht.html">Sexualstrafrecht</a>
                                        </li>
                                        <li class="menu-item ">
                                            <a href="Kapitalstrafrecht.html">Kapitalstrafrecht
                                            </a>
                                        </li>
                                        <li class="menu-item ">
                                            <a href="Wirtschafts- und Steuerstrafrecht.html">Wirtschafts- und Steuerstrafrecht</a>
                                        </li>
                                 
                                    </ul>
                                </li>
                                
                                <li class="menu-item "><a href="blog.php">Presseartikel Thomas Dominkovic</a></li>
                                
                                <li class="menu-item "><a href="karriere.html">Karriere
                                </a></li>

                                <li class="menu-item"><a href="contact.html">Kontakt</a></li>
                                <li class="menu-item"><a href="links.html">Links</a></li>
                             
                                <li class="menu-item "><a href="downloads.html">Downloads</a></li>
                               

                             
                            
                              
                             
                            </ul>
                        </nav>
                    </div>
                    <div class="columns large-1 small-order-1 large-order-2 small-12">
                        <div class="row align-middle menu-search-row">
                            <div class="columns">
                             
                                <div class="nav-menu-icon"><i></i></div>
                            </div>
                           
                        </div>
                    </div>

                </div>
            </div>
        </div>

    </header>

    <!-- BANER SLIDER -->

    <div class="slider-1">
        <div id="layerslider" class="ls-wp-container fitvidsignore" style="width:1180px;height:700px;margin:0 auto;margin-bottom: 0;z-index:5;">
            <div class="ls-slide" data-ls="duration:5000;transition2d:70;timeshift:-500;kenburnsscale:1.2;">
                <img width="2560" height="700" src="images/layerslider/01_slide-01.jpg" class="ls-bg" alt="slide-1">
                <img width="1610" height="700" src="images/layerslider/slider-overlay-01.png" class="ls-l" alt="" style="top:0;left:-300px;text-align:initial;font-weight:400;font-style:normal;text-decoration:none;wordwrap:false;opacity:1;" data-ls="showinfo:1;offsetxin:-100lw;durationin:1500;delayin:200;easingin:easeInOutBack;fadein:false;clipin:0 100% 0 0;offsetxout:-100lw;durationout:1500;startatout:transitioninend + 5100;easingout:easeInBack;fadeout:false;position:fixed;">
                <img width="1570" height="700" src="images/layerslider/slider-overlay-02.png" class="ls-l" alt="" style="top:0;left:-300px;text-align:initial;font-weight:400;font-style:normal;text-decoration:none;wordwrap:false;opacity:1;" data-ls="showinfo:1;offsetxin:-100lw;durationin:1500;easingin:easeInOutBack;fadein:false;clipin:0 100% 0 0;offsetxout:-100lw;durationout:1500;startatout:transitioninend + 5000;easingout:easeInBack;fadeout:false;position:fixed;">
                <h2 style="text-transform:uppercase;top:460px;left:90px;text-align:initial;font-weight:400;font-style:normal;text-decoration:none;word-wrap:normal;opacity:1;font-family:Gudea;font-size:36px;color:#ffffff;" class="ls-l" data-ls="showinfo:1;offsetxin:-100lw;durationin:800;delayin:1500;easingin:easeInOutBack;offsetxout:-100lw;durationout:800;startatout:transitioninend + 4600;easingout:easeInBack;clipout:0 100% 0 0;position:fixed;">
                    BURO STRAFRECHT
                </h2>
                <h2 style="top:510px;left:90px;text-align:initial;font-weight:400;font-style:normal;text-decoration:none;word-wrap:normal;opacity:1;font-family:Gudea;font-size:22px;color:#ffffff;" class="ls-l ls-hide-phone" data-ls="showinfo:1;offsetxin:-100lw;durationin:800;delayin:1700;easingin:easeInOutBack;offsetxout:-100lw;durationout:800;startatout:transitioninend + 4400;easingout:easeInBack;clipout:0 100% 0 0;position:fixed;">
                    Kanzlei für Strafrecht in Mannheim
                </h2>
            </div>

            <div class="ls-slide" data-ls="duration:5000;transition2d:70;timeshift:-500;kenburnsscale:1.2;">
                <img width="2560" height="700" src="images/layerslider/01_slide-02.jpg" class="ls-bg" alt="">
                <img width="1610" height="700" src="images/layerslider/slider-overlay-01.png" class="ls-l" alt="" style="top:0;left:-300px;text-align:initial;font-weight:400;font-style:normal;text-decoration:none;wordwrap:false;opacity:1;" data-ls="showinfo:1;offsetxin:-100lw;durationin:1500;delayin:200;easingin:easeInOutBack;fadein:false;clipin:0 100% 0 0;offsetxout:-100lw;durationout:1500;startatout:transitioninend + 5100;easingout:easeInBack;fadeout:false;position:fixed;">
                <img width="1570" height="700" src="images/layerslider/slider-overlay-02.png" class="ls-l" alt="" style="top:0;left:-300px;text-align:initial;font-weight:400;font-style:normal;text-decoration:none;wordwrap:false;opacity:1;" data-ls="showinfo:1;offsetxin:-100lw;durationin:1500;easingin:easeInOutBack;fadein:false;clipin:0 100% 0 0;offsetxout:-100lw;durationout:1500;startatout:transitioninend + 5000;easingout:easeInBack;fadeout:false;position:fixed;">
                <h2 style="text-transform:uppercase;top:425px;left:90px;text-align:initial;font-weight:400;font-style:normal;text-decoration:none;wordwrap:false;opacity:1;font-family:Gudea;font-size:36px;color:#ffffff;" class="ls-l" data-ls="showinfo:1;offsetxin:-100lw;durationin:800;delayin:1500;easingin:easeInOutBack;offsetxout:-100lw;durationout:800;startatout:transitioninend + 4600;easingout:easeInBack;clipout:0 100% 0 0;position:fixed;">
                    LANGJÄHRIGE ERFAHRUNG
                </h2>
                <h2 style="top:515px;left:90px;text-align:initial;font-weight:400;font-style:normal;text-decoration:none;word-wrap:normal;opacity:1;font-family:Gudea;font-size:22px;color:#ffffff;" class="ls-l ls-hide-phone" data-ls="showinfo:1;offsetxin:-100lw;durationin:800;delayin:1700;easingin:easeInOutBack;offsetxout:-100lw;durationout:800;startatout:transitioninend + 4400;easingout:easeInBack;clipout:0 100% 0 0;position:fixed;">
                    Kenntnis & Erfahrung im Bereich Strafrecht

                </h2>
            </div>
            <div class="ls-slide" data-ls="duration:5000;transition2d:70;timeshift:-500;kenburnsscale:1.2;">
                <img width="2560" height="700" src="images/layerslider/01_slide-03.jpg" class="ls-bg" alt="">
                <img width="1610" height="700" src="images/layerslider/slider-overlay-01.png" class="ls-l" alt="" style="top:0;left:-300px;text-align:initial;font-weight:400;font-style:normal;text-decoration:none;wordwrap:false;opacity:1;" data-ls="showinfo:1;offsetxin:-100lw;durationin:1500;delayin:200;easingin:easeInOutBack;fadein:false;clipin:0 100% 0 0;offsetxout:-100lw;durationout:1500;startatout:transitioninend + 5100;easingout:easeInBack;fadeout:false;position:fixed;">
                <img width="1570" height="700" src="images/layerslider/slider-overlay-02.png" class="ls-l" alt="" style="top:0;left:-300px;text-align:initial;font-weight:400;font-style:normal;text-decoration:none;wordwrap:false;opacity:1;" data-ls="showinfo:1;offsetxin:-100lw;durationin:1500;easingin:easeInOutBack;fadein:false;clipin:0 100% 0 0;offsetxout:-100lw;durationout:1500;startatout:transitioninend + 5000;easingout:easeInBack;fadeout:false;position:fixed;">
                <h2 style="text-transform:uppercase;top:425px;left:90px;text-align:initial;font-weight:400;font-style:normal;text-decoration:none;wordwrap:false;opacity:1;font-family:Gudea;font-size:36px;color:#ffffff;" class="ls-l" data-ls="showinfo:1;offsetxin:-100lw;durationin:800;delayin:1500;easingin:easeInOutBack;offsetxout:-100lw;durationout:800;startatout:transitioninend + 4600;easingout:easeInBack;clipout:0 100% 0 0;position:fixed;">
                    DIENSTLEISTUNGEN IM STRAFRECHT
                </h2>
                <h2 style="top:515px;left:90px;text-align:initial;font-weight:400;font-style:normal;text-decoration:none;word-wrap:normal;opacity:1;font-family:Gudea;font-size:22px;color:#ffffff;" class="ls-l ls-hide-phone" data-ls="showinfo:1;offsetxin:-100lw;durationin:800;delayin:1700;easingin:easeInOutBack;offsetxout:-100lw;durationout:800;startatout:transitioninend + 4400;easingout:easeInBack;clipout:0 100% 0 0;position:fixed;">
                    wie z.B. Betäubungsmittelstrafrecht, Internetstrafrecht,<br>
                    Jugendstrafrecht, Verkehrsstrafrecht, Sexualstrafrecht und<br>
                    vieles mehr
                </h2>
            </div>
            <div class="ls-slide" data-ls="duration:5000;transition2d:70;timeshift:-500;kenburnsscale:1.2;">
                <img width="2560" height="700" src="images/layerslider/01_slide-01.jpg" class="ls-bg" alt="">
                <img width="1610" height="700" src="images/layerslider/slider-overlay-01.png" class="ls-l" alt="" style="top:0;left:-300px;text-align:initial;font-weight:400;font-style:normal;text-decoration:none;wordwrap:false;opacity:1;" data-ls="showinfo:1;offsetxin:-100lw;durationin:1500;delayin:200;easingin:easeInOutBack;fadein:false;clipin:0 100% 0 0;offsetxout:-100lw;durationout:1500;startatout:transitioninend + 5100;easingout:easeInBack;fadeout:false;position:fixed;">
                <img width="1570" height="700" src="images/layerslider/slider-overlay-02.png" class="ls-l" alt="" style="top:0;left:-300px;text-align:initial;font-weight:400;font-style:normal;text-decoration:none;wordwrap:false;opacity:1;" data-ls="showinfo:1;offsetxin:-100lw;durationin:1500;easingin:easeInOutBack;fadein:false;clipin:0 100% 0 0;offsetxout:-100lw;durationout:1500;startatout:transitioninend + 5000;easingout:easeInBack;fadeout:false;position:fixed;">
                <h2 style="text-transform:uppercase;top:425px;left:90px;text-align:initial;font-weight:400;font-style:normal;text-decoration:none;wordwrap:false;opacity:1;font-family:Gudea;font-size:36px;color:#ffffff;" class="ls-l" data-ls="showinfo:1;offsetxin:-100lw;durationin:800;delayin:1500;easingin:easeInOutBack;offsetxout:-100lw;durationout:800;startatout:transitioninend + 4600;easingout:easeInBack;clipout:0 100% 0 0;position:fixed;">
                    RECHTSBEISTAND DURCH DIE BESTEN ANWÄLTE     
                </h2>
                <h2 style="top:515px;left:90px;text-align:initial;font-weight:400;font-style:normal;text-decoration:none;word-wrap:normal;opacity:1;font-family:Gudea;font-size:22px;color:#ffffff;" class="ls-l ls-hide-phone" data-ls="showinfo:1;offsetxin:-100lw;durationin:800;delayin:1700;easingin:easeInOutBack;offsetxout:-100lw;durationout:800;startatout:transitioninend + 4400;easingout:easeInBack;clipout:0 100% 0 0;position:fixed;">
                    mit jahrelanger Erfahrung in jedem Bereich der Rechtspraxis

                </h2>
            </div>
            
            
        </div>
    </div>


    <!-- SERVICES and QUOTE -->
    <div class="row-fluid services-links-row">
        <div class="row">
            <div class="columns small-12">
                <div class="row large-collapse services-links">
                    <div class="columns small-12 large-4">
                        <a href="downloads.html">
                            <div class="services-links__column">
                                <i class="fa fa-users"></i>
                                <div class="services-links__item">
                                    <h2 class="services-links__title">Downloads
                                    </h2>
                                    <p class="services-links__item-content">Hilfreiche Dokumente</p>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="columns small-12 large-4">
                        <a href="bolg.php">
                            <div class="services-links__column">
                                <i class="fa fa-users"></i>
                                <div class="services-links__item">
                                    <h2 class="services-links__title">Presseartikel</h2>
                                    <p class="services-links__item-content">Thomas Dominkovic</p>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="columns small-12 large-4">
                        <a href="karriere.html">
                            <div class="services-links__column">
                                <i class="fa fa-users"></i>
                                <div class="services-links__item">
                                    <h2 class="services-links__title">Karriere</h2>
                                    <p class="services-links__item-content">Mitglied unsere team</p>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row align-center service-blockquote-wrapper">
        <!-- Slider main container -->
        <div class="swiper-container" data-slides-per-view="1" data-loop="true" data-autoplay="3000" data-speed="1000" data-space-between="70" data-slide-effect="fade">
            <!-- Additional required wrapper -->
            <div class="swiper-wrapper">
                <!-- Slides -->
                <div class="swiper-slide service-blockquote">
                    <blockquote class="blockquote service-blockquote__text">
                        Die Stellung gibt dir nie das Recht zu befehlen - nur die Schuldigkeit, so
                        zu leben, dass andere deinen Befehl annehmen können, ohne erniedrigt
                        zu werden.
                    </blockquote>
                    <cite class="service-blockquote__author">Dag Hammarskjöld - Schwedischer Wirtschaftswissenschaftler
                    </cite>
                </div>
                <div class="swiper-slide service-blockquote">
                    <blockquote class="blockquote service-blockquote__text">
                        Das Recht ist Inbegriff der Bedingungen, unter denen die Willkür des
                        einen mit der Willkür des anderen nach einem allgemeinen Gesetz der
                        Freiheit in Einklang gebracht werden kann.
                    </blockquote>
                    <cite class="service-blockquote__author">Immanuel Kant - Deutscher Philosoph</cite>
                </div>
                <div class="swiper-slide service-blockquote">
                    <blockquote class="blockquote service-blockquote__text">
                        Das Reich der Freiheit beginnt in der Tat erst da, wo das Arbeiten, das
                        durch Not und äußere Zweckmäßigkeit bestimmt ist, aufhört; es liegt
                        also der Natur der Sache nach jenseits der Sphäre der eigentlichen
                        materiellen Produktion.”
                    </blockquote>
                    <cite class="service-blockquote__author">Karl Marx - Deutscher Philosoph</cite>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="columns small-12 medium-6 large-4">
            <div class="service-item">
                <figure class="effect-apollo">
                    <img src="images/service-item-thumb-1.png" alt="">
                    <div class="effect-apollo__overlay"></div>
                </figure>
                <h4 class="service-item__title"><a>Karriere</a></h4>
                <p class="service-item__content">Wir geben Ihnen die Möglichkeit, ausgewählte Mandate eigenständig zu bearbeiten, d.h.
                    rechtliche Bewertungen der Sachverhalte zu erarbeiten sowie Entwürfe von Schriftsätzen und
                    Mandantenschreiben zu entwerfen, gegebenfalls mit Mandanten in Haft zu besprechen.</p>
            </div>
        </div>
        <div class="columns small-12 medium-6 large-4">
            <div class="service-item">
                <figure class="effect-apollo">
                    <img src="images/service-item-thumb-2.png" alt="">
                    <div class="effect-apollo__overlay"></div>
                </figure>
                <h4 class="service-item__title"><a>Grundsätze und Werte</a></h4>
                <p class="service-item__content">Als Anwälte sind wir bestrebt, beim Schutz der Rechte unserer Mandanten und bei der
                    Förderung der Gerechtigkeit die Menschenrechte und Grundfreiheiten zu wahren, die durch
                    nationales und internationales Recht anerkannt sind, und jederzeit frei und gewissenhaft im
                    Einklang mit dem Gesetz und den anerkannten Normen und der Ethik des Anwaltsberufs zu
                    handeln.</p>
            </div>
        </div>
        <div class="columns small-12 medium-6 large-4">
            <div class="service-item">
                <figure class="effect-apollo">
                    <img src="images/service-item-thumb-3.png" alt="">
                    <div class="effect-apollo__overlay"></div>
                </figure>
                <h4 class="service-item__title"><a>Unsere Fachwissen</a></h4>
                <p class="service-item__content">Alle in der Kanzlei tätigen Anwälte verfügen selbstverständlich über die
                    entsprechende Qualifikation: Fachanwalt für Strafrecht.</p>
            </div>
        </div>
       
    </div>

    <!-- EXPERIENCE -->
    <div class="row">
        <div class="column">
            <h2 class="banner-title">Bereiche des Strafrechts</h2>
        </div>
    </div>

    <div class="row">
        <div class="small-12 medium-6 large-4 columns tile-col">
            <section class="tile effect-bubba">
                <div class="tile__icon "><img src="images/1.png" style="width: 90px; height:90px"></div>
                <h3 class="tile__title">Betäubungsmittelstrafrecht
                </h3>
                <p class="tile__description">Nach § 4 des Betäubungsmittelgesetzes (BtMG) bedarf der gesamte Verkehr mit Betäubungsmitteln einer Erlaubnis nach § 3 Abs</p>
                <i class="tile__arrow fa fa-arrow-right"></i>
                <a href="Betäubungsmittelstrafrecht.html" class="tile__link"></a>
            </section>
        </div>
        <div class="small-12 medium-6 large-4 columns tile-col">
            <section class="tile effect-bubba">
                <div class="tile__icon "><img src="images/2.png" style="width: 90px; height:90px"></div>
                <h3 class="tile__title">Internetstrafrecht
                </h3>
                <p class="tile__description">Mit diesem Oberbegriff kann man heutzutage eines der wohl breitesten Felder des Strafrechts
                    zusammenfassen:
                    </p>
                    <i class="tile__arrow fa fa-arrow-right"></i>
                <a href="Internetstrafrecht.html" class="tile__link"></a>
            </section>
        </div>
        <div class="small-12 medium-6 large-4 columns tile-col">
            <section class="tile effect-bubba">
                <div class="tile__icon "><img src="images/33.png" style="width: 90px; height:90px"></div>
                <h3 class="tile__title">
                     Jugendstrafrecht</h3>
                <p class="tile__description">Strafverteidigung in Jugendstrafsachen immer eine doppelte Verantwortung zu übernehmen:
                    Zum einen die juristischen Belange des Mandanten zu </p>
                    <i class="tile__arrow fa fa-arrow-right"></i>
                <a href="Jugendstrafrecht.html" class="tile__link"></a>
            </section>
        </div>
        <div class="small-12 medium-6 large-4 columns tile-col">
            <section class="tile effect-bubba">
                <div class="tile__icon "><img src="images/4.png" style="width: 90px; height:90px"></div>
                <h3 class="tile__title">Verkehrsstrafrecht</h3>
                <p class="tile__description">Verkehrsrechtliche Verfahren werden von den Ermittlungsbehörden leider viel zu häufig als
                    Massenverfahren behandelt, der</p>
                    <i class="tile__arrow fa fa-arrow-right"></i>
                <a href="Verkehrsstrafrecht.html" class="tile__link"></a>
            </section>
        </div>
        <div class="small-12 medium-6 large-4 columns tile-col">
            <section class="tile effect-bubba">
                <div class="tile__icon "><img src="images/5.png" style="width: 90px; height:90px"></div>
                <h3 class="tile__title">Sexualstrafrecht
                </h3>
                <p class="tile__description">Sexuelle Begegnungen können sehr unterschiedlich verlaufen und von den Beteiligten – je nach
                    sozialer Herkunft, sexueller Reife und Erfahrung </p>
                    <i class="tile__arrow fa fa-arrow-right"></i>
                <a href="Sexualstrafrecht.html" class="tile__link"></a>
            </section>
        </div>
        <div class="small-12 medium-6 large-4 columns tile-col">
            <section class="tile effect-bubba">
                <div class="tile__icon "><img src="images/6.png" style="width: 90px; height:90px"></div>
                <h3 class="tile__title">Kapitalstrafrecht
                </h3>
                <p class="tile__description">Das Grunddelikt des § 177 Abs.1 StGB bedroht denjenigen mit einer Freiheitsstrafe von „1 Jahr
                    bis zu 15 Jahren“, der eine andere Person mit Gewalt,</p>
                <i class="tile__arrow fa fa-arrow-right"></i>
                <a href="Kapitalstrafrecht.html" class="tile__link"></a>
            </section>
        </div>
    </div>
   

<!-- LATEST POSTS -->
<div class="row latest-posts-wrapper align-center">
		<div class="small-12 medium-6 large-4 column">
			<section class="widget widget-latest-posts-thumb">
				<h3 class="widget-title">Latest Publications</h3>
                
				<ul>
                <?php
                    while ($row1 = mysqli_fetch_assoc($populer)){
                        ?>
					<li>
                   
						<a href="singlepage.php?id=<?= $row1['id'] ?>" class="widget-latest-posts-thumb__thumb effect-apollo">
							<img src="uploads/<?= $row1['image'] ?>" alt="">
							<div class="effect-apollo__overlay"></div>
						</a>
						<div class="widget-latest-posts-thumb__item-meta">
							<a class="widget__date" ><?= $row1['date'] ?></a>
							<h4><a><?= substr($row1['title'],0,40) ?></a></h4>
						</div>
                        
					</li>
                    <?php } ?>
					
				</ul>
			</section>
		</div>
		<div class="small-12 medium-6 large-4 column">
			<section class="widget widget-latest-posts">
				<h3 class="widget-title">Find a Lawyer</h3>
				
            <div class="row">
                <div class="column">
                    <form class="search-form">
                        <label>Name</label>
                        <input type="text" name="name" value="">
                        <label>Sectors</label>
                        <select name="sectors">
    <option disabled selected value="">&nbsp;</option>
    <option value="option1">option-1</option>
    <option value="option2">option-2</option>
    <option value="option3">option-3</option>
  </select>
                        <label>Legal areas</label>
                        <select name="legal">
    <option disabled selected value="">&nbsp;</option>
    <option value="option1">option-1</option>
    <option value="option2">option-2</option>
    <option value="option3">option-3</option>
  </select>
                        <label>Offices</label>
                        <select name="ofices">
    <option disabled selected value="">&nbsp;</option>
    <option value="option1">option-1</option>
    <option value="option2">option-2</option>
    <option value="option3">option-3</option>
  </select>
                        <button class="btn btn--small search-form__submit" type="submit" name="name">Search</button>
                    </form>

                </div>
            </div>
			</section>
		</div>
		<div class="small-12 medium-6 large-4 column">
			<section class="widget widget-blockquote">
				<h3 class="widget-title">TESTIMONIALS</h3>
				<div class="swiper-container" data-slides-per-view="1" data-loop="true" data-autoplay="3000" data-speed="3000" data-space-between="70" data-slide-effect="fade">
					<!-- Additional required wrapper -->
					<div class="swiper-wrapper">
						<!-- Slides -->
						<div class="swiper-slide">
							<blockquote class="blockquote blockquote--style-1">
								Amet magna roncus, ultrices purus sed, egestas turpis. Praesent sit amet rhoncus nisi. Etiam tristique velit ut felis ultrices.
							</blockquote>
							<div class="blockquote-author">
								<img src="images/blockquote-author-photo.jpg" alt="" class="blockquote-author__photo">
								<div class="blockquote-author__info">
									<cite class="blockquote-author__name">Richard Bennett</cite>
									<cite class="blockquote-author__position">Chief Executive</cite>
								</div>
							</div>
						</div>
						<div class="swiper-slide">
							<blockquote class="blockquote blockquote--style-1">
								Amet magna roncus, ultrices purus sed, egestas turpis. Praesent sit amet rhoncus nisi. Etiam tristique velit ut felis ultrices pulvinar nec consectetur non, tincidunt malesquada lorem.
							</blockquote>
							<div class="blockquote-author">
								<img src="images/blockquote-author-photo-2.jpg" alt="" class="blockquote-author__photo">
								<div class="blockquote-author__info">
									<cite class="blockquote-author__name">Richard Bennett</cite>
									<cite class="blockquote-author__position">Chief Executive</cite>
								</div>
							</div>
						</div>
						<div class="swiper-slide">
							<blockquote class="blockquote blockquote--style-1">
								Praesent sit amet rhoncus nisi. Etiam tristique velit ut felis ultrices pulvinar nec consectetur tincidunt malesquada lorem. Phasellus imperdiet risus eget augue fermentum pharetra.
							</blockquote>
							<div class="blockquote-author">
								<img src="images/blockquote-author-photo-4.jpg" alt="" class="blockquote-author__photo">
								<div class="blockquote-author__info">
									<cite class="blockquote-author__name">Amy Forbes</cite>
									<cite class="blockquote-author__position">Partner</cite>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
		</div>
	</div>



    <!-- OUR PEOPLE -->
    <div class="row our-people-wrapper0" id="people">
        <div class="small-12 large-8 column">
            <div class="row">
                <div class="column">
                    <h3 class="block-title">Unsere Verteidiger</h3>
                </div>
            </div>
            <div class="row">
                <div class="small-6 medium-6 column bg-1">



                    <div class="team-person">
                        <div class="team-person__img effect-apollo">
                            <img src="images/team-person-1.jpg" alt="team-person" />
                            <div class="effect-apollo__overlay"></div>
                        </div>
                        <h5 class="team-person__name">Thomas Dominkovic</h5>
                        <p class="team-person__position">Rechtsanwalt und Fachanwalt für Strafrecht</p>
                        <a href="Thomas Dominkovic.html" class="fa fa-arrow-right">View profile</a>
                    </div>
                </div>
                <div class="small-6 medium-6 column bg-1">



                    <div class="team-person">
                        <div class="team-person__img effect-apollo">
                            <img src="images/team-person-2.jpg" alt="team-person" />
                            <div class="effect-apollo__overlay"></div>
                        </div>
                        <h5 class="team-person__name">Kayahan Aydin</h5>
                        <p class="team-person__position">Rechtsanwalt und Fachanwalt für Strafrech</p>
                        <a href="Kayahan Aydin.html" class="fa fa-arrow-right">View profile</a>
                    </div>
                </div>
               
               
            </div>
        </div>
        <div class="small-12 large-4 column" style="margin-top: 104px;">
        <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d5184.206776516018!2d8.473151!3d49.482554!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xcf60c429d72955f2!2sThomas%20Dominkovic!5e0!3m2!1sde!2sde!4v1671901461369!5m2!1sde!2sde" width="400" height="488" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
    </div>

    <!-- GET A QUOTE -->
    <div class="get-a-quote">
        <div class="row align-center">
            <div class="column small-12 medium-expand">
                <h3 class="get-a-quote__text">Auf der Suche nach einem erstklassigen Businessplan-Berater?</h3>
            </div>
            <div class="column small-12 shrink">
                <a href="contact.html" class="btn get-a-quote__link">Ein Angebot bekommen</a>
            </div>
        </div>
    </div>

    <!-- FOOTER -->
    <footer class="main-footer dark-section">
        <div class="row row-widgets">
            <div class="columns small-12 medium-6 large-4">
                <section class="widget widget-address">
                    <h3 class="widget-title">Kontakte</h3>
                    <p>Thomas Dominkovic, Kaiserring 38, 68161 Mannheim, Germany</p>
                    <p class="widget-address__info icon-phone-3">+49 621 120 91-0</p>
                    <p class="widget-address__info icon-mail-3"><a href="mailto:lawyerburo@law.com">lawyerburo@law.com</a></p>
                </section>
                <section class="widget widget-subscribe">
                    <h3 class="widget-title">BLEIBEN SIE MIT UNS IN KONTAKT</h3>
                    <p>Informationen über aktuelle Ereignisse rund um unser Unternehmen</p>
                    <form>
                        <input type="text" placeholder="Enter your e-mail">
                        <button type="submit" class="widget-subscribe__submit fa fa-arrow-right"></button>
                    </form>
                </section>

            </div>
            <div class="columns small-12 medium-6 large-4">
                <section class="widget widget_pages">
                    <h3 class="widget-title">ERKUNDEN SIE UNSERE WEBSITE</h3>
                    <ul>
                        <li><a href="/">Startseite</a></li>
                        <li><a href="about.html">Über uns</a></li>
                        <li><a href="blog.php">Presseartikel Thomas Dominkovic</a></li>
                        <li><a href="karriere.html">Karriere</a></li>
                        <li><a href="contact.html">Kontakt</a></li>
                        <li><a href="links.html">Links</a></li>
                    </ul>
                </section>
            </div>
            <div class="columns small-12 medium-6 large-4">
                <section class="widget widget_categories">
                    <h3 class="widget-title">Bereiche des Strafrechts</h3>
                    <ul>
                        <li class="cat-item">
                            <a href="Betäubungsmittelstrafrecht.html">Betäubungsmittelstrafrecht</a>
                        </li>
                        <li class="cat-item">
                            <a href="Internetstrafrecht.html">Internetstrafrecht</a>
                        </li>
                        <li class="cat-item">
                            <a href="Jugendstrafrecht.html">Jugendstrafrecht</a>
                        </li>
                        <li class="cat-item">
                            <a href="Verkehrsstrafrecht.html">Verkehrsstrafrecht</a>
                        </li>
                        
                        <li class="cat-item">
                            <a href="Sexualstrafrecht.html">Sexualstrafrecht</a>
                        </li>
                        <li class="cat-item">
                            <a href="Kapitalstrafrecht.html">Kapitalstrafrecht</a>
                        </li>
                        <li class="cat-item">
                            <a href="Wirtschafts- und Steuerstrafrecht.html">Wirtschafts- und Steuerstrafrecht</a>
                        </li>
                    </ul>
                </section>
            </div>
           
        </div>
        <div class="row">
            <div class="columns small-12">
                <div class="row align-justify align-middle logo-socials-footer small-collapse">
                    <div class="columns small-12 medium-expand">
                        <div class="logo">
                            <a href="index.php">
								<img src="images/logo-footer.png" alt="Logo" style="width: 300px;">
							</a>
                        </div>
                    </div>
                    <div class="columns small-12 shrink">
                        <div class="socials">
                            <a href="#"><i class="fa fa-twitter"></i></a>
                            <a href="#"><i class="fa fa-facebook"></i></a>
                            <a href="#"><i class="fa fa-rss-1"></i></a>
                            <a href="#"><i class="fa fa-linkedin"></i></a>
                            <a href="#"><i class="fa fa-pinterest-4"></i></a>
                            <a href="#"><i class="fa fa-gplus-1"></i></a>
                            <a href="#"><i class="fa fa-instagram"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="columns small-12">
                <div class="row align-justify align-middle copyright small-collapse">
                    <div class="columns small-12 medium-expand">
                        Copyright © 2023. Kanzlei für Strafrecht
                        . Konzeption & Umsetzung: quadrat.media
                    </div>
                    
                </div>
            </div>
        </div>
    </footer>


    <script src="js/jquery.js"></script>
    <script src="js/swiper.jquery.min.js"></script>
    <script src="js/imagesloaded.pkgd.min.js"></script>
    <script src="js/isotope.pkgd.min.js"></script>
    <script src="js/jquery.matchHeight.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCmb9paOeg40eUIZzT4DIkTolSYaU3X-qw"></script>
    <script src="js/main.js"></script>

    <!-- External libraries: jQuery & GreenSock -->
    <script src="layerslider/js/jquery.js"></script>
    <script src="layerslider/js/greensock.js"></script>

    <!-- LayerSlider script files -->
    <script src="layerslider/js/layerslider.transitions.js"></script>
    <script src="layerslider/js/layerslider.kreaturamedia.jquery.js"></script>
    <!-- Initializing the slider -->
    <script>
        jQuery("#layerslider").layerSlider({
            type: 'fullwidth',
            allowFullscreen: false,
            cycles: 3,
            speed: 1500,
            navStartStop: false,
            navButtons: false,
            popupWidth: 640,
            popupHeight: 360,
            skinsPath: 'layerslider/skins/',
            hideOnMobile: true
        });
    </script>
</body>

</html><?php
require_once 'footer.php';
?>