</div><!-- end row -->
</div><!-- end container -->
</section>

<?php
use App\classes\Site;
$ob = Site::displaySocialLink();
$data = mysqli_fetch_assoc($ob);
?>
<footer class="footer">
    <div class="container">
        <div class="row">
            <div class="col-lg-5">
                <div class="widget">
                    <div class="footer-text text-left">
                        <a href="index.php"><img src="images/logo-footer.png" alt="Logo" style="width: 300px;" class="img-fluid"></a>
                        <p>Thomas Dominkovic, Kaiserring 38, 68161 Mannheim, Germany</p>
                        <p>+49 621 120 91-0</p>
                        <p>lawyerburo@law.com</p>
                        <div class="social">
                            <a href="<?= $data['facebook']?>" data-toggle="tooltip" data-placement="bottom" title="Facebook"><i class="fa fa-facebook"></i></a>
                            <a href="<?= $data['twitter']?>" data-toggle="tooltip" data-placement="bottom" title="Twitter"><i class="fa fa-twitter"></i></a>
                            <a href="<?= $data['instagram']?>" data-toggle="tooltip" data-placement="bottom" title="Instagram"><i class="fa fa-instagram"></i></a>
                            
                            <a href="<?= $data['linkedin']?>" data-toggle="tooltip" data-placement="bottom" title="Linkedin"><i class="fa fa-linkedin"></i></a>
                        </div>

                        <hr class="invis">

                     
                    </div><!-- end footer-text -->
                </div><!-- end widget -->
            </div><!-- end col -->

            <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12">
                <div class="widget">
                    <h2 class="widget-title">BEREICHE DES STRAFRECHTS</h2>
                    <div class="link-widget">
                        <ul>
                        <li >
                            <a href="Betäubungsmittelstrafrecht.html">Betäubungsmittelstrafrecht</a>
                        </li>
                        <li >
                            <a href="Internetstrafrecht.html">Internetstrafrecht</a>
                        </li>
                        <li >
                            <a href="Jugendstrafrecht.html">Jugendstrafrecht</a>
                        </li>
                        <li >
                            <a href="Verkehrsstrafrecht.html">Verkehrsstrafrecht</a>
                        </li>
                        
                        <li >
                            <a href="Sexualstrafrecht.html">Sexualstrafrecht</a>
                        </li>
                        <li >
                            <a href="Kapitalstrafrecht.html">Kapitalstrafrecht</a>
                        </li>
                        <li >
                            <a href="Wirtschafts- und Steuerstrafrecht.html">Wirtschafts- und Steuerstrafrecht</a>
                        </li>
                        </ul>
                    </div><!-- end link-widget -->
                </div><!-- end widget -->
            </div><!-- end col -->

            <div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
                <div class="widget">
                    <h2 class="widget-title">ERKUNDEN SIE UNSERE WEBSITE</h2>
                    <div class="link-widget">
                        <ul>
                        <li><a href="/">Startseite</a></li>
                        <li><a href="about.html">Über uns</a></li>
                        <li><a href="blog.php">Presseartikel Thomas Dominkovic</a></li>
                        <li><a href="karriere.html">Karriere</a></li>
                        <li><a href="contact.html">Kontakt</a></li>
                        <li><a href="links.html">Links</a></li>
                        </ul>
                    </div><!-- end link-widget -->
                </div><!-- end widget -->
            </div><!-- end col -->
        </div>

        <div class="row" >
            <div class="col-md-12 text-center">
                <br>
                <div class="copyright"> <?= $siteData['footer']?> <a href="<?= $data['footerlink']?>"><?= $data['footertxt']?></a>.</div>
            </div>
        </div>
    </div><!-- end container -->
</footer><!-- end footer -->

<div class="dmtop">Scroll to Top</div>

</div><!-- end wrapper -->

<!-- Core JavaScript
================================================== -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/tether.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/custom.js"></script>

</body>
</html>