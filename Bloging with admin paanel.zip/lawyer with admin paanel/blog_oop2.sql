-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 26, 2022 at 11:53 AM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blog_oop2`
--

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `id` int(3) NOT NULL,
  `cat_id` int(3) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `tag` text NOT NULL,
  `admin` varchar(100) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `rate` tinyint(2) NOT NULL,
  `image` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`id`, `cat_id`, `title`, `content`, `tag`, `admin`, `status`, `rate`, `image`, `date`) VALUES
(53, 23, 'Post', 'waa dsd f e erf', 'law firm', 'admin', 1, 0, '568597.png', '2022-12-25 21:56:27'),
(54, 24, 'Post 2', 'wdddddddddddddddvfvf fv fv cv df', 'waqaaaaa', 'admin', 1, 0, '436542.png', '2022-12-25 21:57:04'),
(55, 24, 'Post technology', 'computer technolhgy us n j j hj ldbluadh lsiC', 'wa', 'admin', 1, 0, '615605.png', '2022-12-26 09:26:25');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(2) NOT NULL,
  `category_name` varchar(100) NOT NULL,
  `status` tinyint(2) NOT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `admin_name` varchar(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category_name`, `status`, `create_time`, `admin_name`) VALUES
(23, 'law frim', 1, '2022-12-25 21:56:06', 'admin'),
(24, 'waqas', 1, '2022-12-25 21:56:35', 'admin'),
(25, 'Technolgy', 1, '2022-12-26 09:25:47', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `mails`
--

CREATE TABLE `mails` (
  `id` int(5) NOT NULL,
  `name` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `subject` varchar(200) NOT NULL,
  `phone` varchar(16) NOT NULL,
  `message` text NOT NULL,
  `status` tinyint(3) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mails`
--

INSERT INTO `mails` (`id`, `name`, `email`, `subject`, `phone`, `message`, `status`, `date`) VALUES
(3, 'ee', 'arshahin@gmail.com', 'How we help?', '+8801754100439', 'm vulputate urna id libero auctor maximus. Nulla dignissim ligula diam, in sollicitudin ligula congue quis turpis dui urna nibhs. ', 0, '2020-08-13 13:48:27'),
(4, 'ee', 'arshahin@gmail.com', 'How we help?', '+8801754100439', 'm vulputate urna id libero auctor maximus. Nulla dignissim ligula diam, in sollicitudin ligula congue quis turpis dui urna nibhs. ', 0, '2020-08-13 13:49:15'),
(7, 'Anisur Rahman Shahin', 'arshahin@gmail.com', 'How we help?', '+8801754100439', 'al blog for handcrafted, cameramade photography content, fashion styles from ind', 0, '2020-08-13 13:57:26'),
(8, 'Anisur Rahman Shahin', 's@gmail.com', 'How we help?', '+8801754100439', 'te urna id libero auctor maximus. Nulla dignissim ligula diam, in sollicitudin ligula congue quis turpis dui urna nibhs. ', 0, '2020-08-13 13:59:53'),
(9, 'Anisur Rahman Shahin', 's@gmail.com', 'How we help?', '+8801754100439', 'te urna id libero auctor maximus. Nulla dignissim ligula diam, in sollicitudin ligula congue quis turpis dui urna nibhs. ', 0, '2020-08-13 14:00:00'),
(11, 'coder shahin', 'arshahin625@gmail.com', 'Pre-Sale Question', '01994439594', 'Etiam vulputate urna id libero auctor maximus. Nulla dignissim ligula diam, in sollicitudin ligula congue quis turpis dui urna nibhs.', 0, '2020-08-13 14:03:12'),
(12, 'Asikur Rahman Shawon', 'k@gmail.com', 'Who we are', '01754100439', 'How we help?\r\n\r\nEtiam vulputate urna id libero auctor maximus. Nulla dignissim ligula diam, in sollicitudin ligula congue quis turpis dui urna nibhs. ', 0, '2020-08-13 14:36:59'),
(14, 'shahin', 'k@gmail.com', 'Tech Blog is a technology blog', '+8801754100439', 'Fusce dapibus nunc quis quam tempor vestibulum sit amet consequat enim. Pellentesque blandit hendrerit placerat. Integertis non.Fusce dapibus nunc quis quam tempor vestibulum sit amet consequat enim. Pellentesque blandit hendrerit placerat. Integertis non.Fusce dapibus nunc quis quam tempor vestibulum sit amet consequat enim. Pellentesque blandit hendrerit placerat. Integertis non.<h1>hfhfhf</h1>\"rrrrr][\"', 0, '2020-08-14 03:11:18'),
(15, 'AR Shahin', 'mdshahinmije@yahoo.com', 'How we help?', '01994439594', 'ech Blog is a personal blog for handcrafted, cameramade photography content, fashion styles from independent creatives around the world.ech Blog is a personal blog for handcrafted, cameramade photography content, fashion styles from independent creatives around the world.   \r\n                        \r\n                              \r\n                        ', 2, '2020-08-14 03:50:58'),
(16, 'AR Shahin', 'mdshahinmije@yahoo.com', 'How we help?', '01994439594', 'ech Blog is a personal blog for handcrafted, cameramade photography content, fashion styles from independent creatives around the world.ech Blog is a personal blog for handcrafted, cameramade photography content, fashion styles from independent creatives around the world.   \r\n                        \r\n                              \r\n                        ', 2, '2020-08-14 03:52:18'),
(17, 'coder shahin', 'mdshahinmije@yahoo.com', 'dd', '01994439594', 'm ligula diam, in sollicitudin ligula congue quis turpis dui urna nibhs.', 2, '2020-08-14 03:58:33'),
(18, 'coder shahin', 'mdshahinmije@yahoo.com', 'dd', '01994439594', 'm ligula diam, in sollicitudin ligula congue quis turpis dui urna nibhs.', 0, '2020-08-14 03:59:11'),
(19, 'coder shahin', 'mdshahinmije@yahoo.com', 'dd', '01994439594', 'm ligula diam, in sollicitudin ligula congue quis turpis dui urna nibhs.', 0, '2020-08-14 03:59:28'),
(20, 'Anisur Rahman Shahin', 'mdshahinmije96@gmail.com', 'How we help?', '+8801754100439', 'lp?\r\n\r\nEtiam vulputate urna id libero auctor maximus. Nulla dignissim ligula diam, in sollicitudin ligula congue quis turpis dui urna nibhs.', 2, '2020-08-14 05:36:10'),
(21, 'Asik Newaz Sabbir', 'arshahin@gmail.com', 'How we help?', '+8801754100439', 'Pre-Sale Question\r\n\r\nFusce dapibus nunc quis quam tempor vestibulum sit amet consequat enim. Pellentesque blandit hendrerit placerat. Integertis non.', 2, '2020-08-15 11:34:34'),
(22, 'Anisur Rahman Shahin', 'arshahin@gmail.com', 'demo', '+8801754100439', 'this is demo mail', 2, '2020-08-15 14:45:38'),
(23, 'Anisur Rahman Shahin', 'arshahin@gmail.com', 'How we help?', '+8801754100439', 'gg', 2, '2020-08-15 14:47:04'),
(24, 'Anisur Rahman Shahin', 'arshahin@gmail.com', 'dd', 'cd', 'dd', 0, '2020-08-15 14:58:30');

-- --------------------------------------------------------

--
-- Table structure for table `replies`
--

CREATE TABLE `replies` (
  `id` int(2) NOT NULL,
  `email_id` int(2) NOT NULL,
  `user` varchar(50) NOT NULL,
  `reply` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `replies`
--

INSERT INTO `replies` (`id`, `email_id`, `user`, `reply`, `date`) VALUES
(1, 17, 'admin', 'ffff', '2020-08-14 05:22:05'),
(2, 17, 'admin', 'ccc', '2020-08-14 05:25:39'),
(3, 17, 'admin', 'dddaaa', '2020-08-14 05:26:34'),
(4, 16, 'admin', 'ok done', '2020-08-14 05:28:35'),
(5, 15, 'admin', 'g', '2020-08-14 05:32:46'),
(6, 20, 'admin', 'ok done', '2020-08-14 05:36:26'),
(7, 20, 'admin', 'ok done', '2020-08-14 14:13:51'),
(8, 21, 'asik', 'ok ', '2020-08-15 14:26:53'),
(9, 25, 'admin', 'this id demo reply', '2020-08-15 15:05:28');

-- --------------------------------------------------------

--
-- Table structure for table `site`
--

CREATE TABLE `site` (
  `id` int(2) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `footer` varchar(255) NOT NULL,
  `postdisplay` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `site`
--

INSERT INTO `site` (`id`, `logo`, `title`, `footer`, `postdisplay`) VALUES
(1, 'logo.png', 'Presseartikel', 'Copyright Â© 2023. Kanzlei fÃ¼r Strafrecht . Konzeption & Umsetzung: quadrat.media', 3);

-- --------------------------------------------------------

--
-- Table structure for table `social_links`
--

CREATE TABLE `social_links` (
  `id` int(2) NOT NULL,
  `facebook` varchar(255) NOT NULL,
  `twitter` varchar(255) NOT NULL,
  `instagram` varchar(255) NOT NULL,
  `linkedin` varchar(255) NOT NULL,
  `github` varchar(255) NOT NULL,
  `footerlink` varchar(255) NOT NULL,
  `footertxt` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `social_links`
--

INSERT INTO `social_links` (`id`, `facebook`, `twitter`, `instagram`, `linkedin`, `github`, `footerlink`, `footertxt`) VALUES
(1, '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(200) NOT NULL,
  `image` varchar(255) NOT NULL,
  `bio` text NOT NULL,
  `role` tinyint(5) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fname`, `lname`, `username`, `email`, `password`, `image`, `bio`, `role`, `date`) VALUES
(6, 'Waqas ', 'Mustafa', 'admin', 'admin@admin.com', '123456', 'shahin-formal.png', 'WAQAS        ', 1, '2020-08-14 14:36:53');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mails`
--
ALTER TABLE `mails`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `replies`
--
ALTER TABLE `replies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `site`
--
ALTER TABLE `site`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `social_links`
--
ALTER TABLE `social_links`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `mails`
--
ALTER TABLE `mails`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `replies`
--
ALTER TABLE `replies`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `site`
--
ALTER TABLE `site`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `social_links`
--
ALTER TABLE `social_links`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
